# eureka_client/__init__.py
"""
eureka_client.py

This module provides an implementation of a client for registering and interacting
with an Eureka service registry. Eureka is a service discovery tool primarily used in
cloud-based applications to manage service instances.

The `EurekaClient` class allows users to register their service instances with an
Eureka server, send heartbeat signals to indicate they are still alive, and deregister
when they are no longer available. This functionality is essential for maintaining
service availability and discovery in a microservices architecture.

Key Features:
- Register a service instance with an Eureka server.
- Send regular heartbeat signals to the Eureka server to indicate the service is active.
- Deregister the service instance when it stops running.
- Configurable heartbeat interval for flexibility in registration frequency.

Usage Example:
    from eureka_client import EurekaClient

    client = EurekaClient(
        eureka_server='http://localhost:8761',
        app_name='MY-PY-SERVICE',
        instance_id='my-py-service-1',
        port=8080,
        heartbeat_interval=30.0
    )
    client.start()  # Starts registration and heartbeat sending
    # ... application logic ...
    client.stop()   # Stops heartbeat and deregisters the instance

Attributes:
    logger (logging.Logger): Logger instance to log registration and heartbeat status.
"""
from .client import EurekaClient

__all__ = ["EurekaClient"]
