# eureka_client/client.py
import requests
import threading
import time
import socket
import logging
import sys
import signal

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class EurekaClient:
    def __init__(
        self,
        eureka_server: str,
        app_name: str,
        instance_id: str,
        port: int,
        heartbeat_interval: float = 30.0,
    ):
        """
        :param eureka_server: Base URL of Eureka server (e.g. http://localhost:8761)
        :param app_name: Logical name of your service in Eureka (e.g. "MY-PY-SERVICE")
        :param instance_id: Unique ID for this instance (e.g. "my-py-service-1")
        :param port: Port your script or service is (hypothetically) running on
        :param heartbeat_interval: Seconds between heartbeats
        """
        self._eureka_server = eureka_server.rstrip("/")
        self._app_name = app_name.upper()  # Eureka requires uppercase
        self._instance_id = instance_id
        self._port = port
        self._heartbeat_interval = heartbeat_interval

        self.stop_event = threading.Event()
        self._heartbeat_thread = None

        self.hostname = socket.gethostname()
        self.ip_address = socket.gethostbyname(self.hostname)
        self.domain_name = socket.getfqdn(self.hostname)

        self.registration_url = f"{self._eureka_server}/eureka/apps/{self._app_name}"

        self.custom_instance_id = f"{self.domain_name}:{self._instance_id}:{self._port}"
        self.heartbeat_url = f"{self._eureka_server}/eureka/apps/{self._app_name}/{self.custom_instance_id}"

        self.auth = None

    def build_xml_payload(self):
        """
        Build the XML payload for Eureka registration.
        """
        return f"""<?xml version="1.0" encoding="UTF-8"?>
        <instance>
            <instanceId>{self.custom_instance_id}</instanceId>
            <hostName>{self.domain_name}</hostName>
            <app>{self._app_name}</app>
            <ipAddr>{self.ip_address}</ipAddr>
            <vipAddress>{self._instance_id}</vipAddress>
            <port enabled="true">{self._port}</port>
            <dataCenterInfo class="com.netflix.appinfo.InstanceInfo$DefaultDataCenterInfo">
                <name>MyOwn</name>
            </dataCenterInfo>
            <status>UP</status>
        </instance>"""

    def register(self):
        """
        POST to register this instance with Eureka.
        """
        headers = {"Content-Type": "application/xml", "Accept": "application/xml"}
        xml_body = self.build_xml_payload()
        resp = requests.post(
            self.registration_url,
            data=xml_body,
            headers=headers,
            auth=self.auth,
            timeout=10,
        )

        if resp.status_code in (
            204,
            200,
        ):  # Eureka can respond 204 No Content on success
            logger.info(
                f"Registered with Eureka: {self._instance_id}, status={resp.status_code}"
            )
        else:
            logger.warning(
                f"Failed to register with Eureka: status={resp.status_code}, msg={resp.text}"
            )

    def send_heartbeat(self):
        """
        PUT to let Eureka know we're still alive.
        """
        headers = {"Accept": "application/xml"}
        resp = requests.put(
            self.heartbeat_url,
            headers=headers,
            auth=self.auth,
            timeout=10,
        )

        if resp.status_code in (204, 200):
            logger.info(f"Heartbeat success: {self._instance_id}")
        else:
            logger.warning(
                f"Failed to send heartbeat to Eureka: status={resp.status_code}, msg={resp.text}"
            )

    def deregister(self):
        """
        DELETE to remove our instance from Eureka.
        """
        resp = requests.delete(self.heartbeat_url, auth=self.auth, timeout=10)

        if resp.status_code in (204, 200, 202):
            logger.info(f"Deregistered from Eureka: {self._instance_id}")
        else:
            logger.warning(
                f"Failed to deregister from Eureka: status={resp.status_code}, msg={resp.text}"
            )

    def _heartbeat_loop(self):
        """
        Background thread that sends heartbeats until stop_event is set.
        """
        while not self.stop_event.is_set():
            self.send_heartbeat()
            time.sleep(self._heartbeat_interval)

    def start(self):
        """
        Register and start the heartbeat thread.
        """
        self.register()
        self.heartbeat_thread = threading.Thread(
            target=self._heartbeat_loop, daemon=True
        )
        self.heartbeat_thread.start()

    def stop(self):
        """
        Stop sending heartbeats and deregister from Eureka.
        """
        self.stop_event.set()
        if self.heartbeat_thread:
            self.heartbeat_thread.join(timeout=5)
        self.deregister()
